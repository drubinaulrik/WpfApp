﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ujnev.KeyDown += Ujnev_KeyDown;
        }

        private void Ujnev_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                hozzaad_Click(sender, e);
            }
        }

        private void hozzaad_Click(object sender, RoutedEventArgs e)
        {
            if(ujnev.Text=="")
            {
                MessageBox.Show("Nem adott meg nevet!");
            }
            else if(!nevlista.Items.Contains(ujnev.Text))
            {
                nevlista.Items.Add(ujnev.Text);
                ujnev.Text=String.Empty;
                elemszam.Text=nevlista.Items.Count.ToString();
            }
            else
            {
                MessageBox.Show("A név már szerepel a listában!");
                ujnev.Text = String.Empty;
            }
            
                     
        }

        private void torol_Click(object sender, RoutedEventArgs e)
        {
            if (nevlista.Items.Count > 0 && nevlista.SelectedItems.Count > 0)
            {
                nevlista.Items.Remove(nevlista.SelectedItem);
                elemszam.Text = nevlista.Items.Count.ToString();
            }
            else
            {
                MessageBox.Show("Nincs kijelölt elem vagy nincs elem a listában!");
            }
        }

        private void urit_Click(object sender, RoutedEventArgs e)
        {
            var valasz=MessageBox.Show("Valóban törölni akar minden elemet?","Törlés",MessageBoxButton.YesNo,MessageBoxImage.Question);
            if(valasz == MessageBoxResult.Yes)
            {
                nevlista.Items.Clear();
                elemszam.Text = nevlista.Items.Count.ToString();
            }
        }

        private void rendez_Click(object sender, RoutedEventArgs e)
        {
            nevlista.Items.SortDescriptions.Add(new System.ComponentModel.SortDescription("",System.ComponentModel.ListSortDirection.Ascending));
        }
    }
}